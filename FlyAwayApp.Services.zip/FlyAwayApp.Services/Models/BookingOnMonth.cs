﻿using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.TravelAway.Services.Models
{
    public class BookingOnMonth
    {
        [Key]
        public long SerialPackageDetailsId { get; set; }
        public int NumberOfBookings { get; set; }
    }
}
