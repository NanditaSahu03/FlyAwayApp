﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.TravelAway.Services.Models
{
    public class BookingDetails
    {
        public int BookingId { get; set; }
        public string EmailId { get; set; }
        public long SerialPackageDetailsId { get; set; }
        public decimal PhoneNo { get; set; }
        public string UserAddress { get; set; }
        public DateTime DateOfTravel { get; set; }
        public int Adults { get; set; }
        public int? Children { get; set; }
        public decimal Price { get; set; }
        public string Status { get; set; }
    }
}
