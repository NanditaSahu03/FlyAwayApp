﻿using Infosys.TravelAway.DataAccessLayer.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.TravelAway.Services.Models
{
    public class Users
    {
        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }
        [Key]
        [Required]
        [RegularExpression("^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+$")]
        public string EmailId { get; set; }

        [Required]
        [StringLength(16,MinimumLength=7)]
        public string UserPassword { get; set; }
        public Nullable<byte> RoleId { get; set; }

        [Required]
        public string Gender { get; set; }

        [Required]

        public decimal PhoneNo { get; set; }
        [Required]
        public DateTime DateOfBirth { get; set; }
        [Required]
        public string UserAddress { get; set; }
        public virtual Roles Role { get; set; }
    }
}
