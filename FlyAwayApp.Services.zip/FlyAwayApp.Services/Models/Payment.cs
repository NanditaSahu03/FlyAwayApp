﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.TravelAway.Services.Models
{
    public class Payment
    {

        public int BookingId { get; set; }
        public string EmailId { get; set; }


    }
}
