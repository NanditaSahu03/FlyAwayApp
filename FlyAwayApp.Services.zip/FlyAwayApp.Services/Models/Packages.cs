﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.TravelAway.Services.Models
{
    public class Packages
    {
        public byte PackageId { get; set; }
        public string PackageName { get; set; }
        public string PackageDescription { get; set; }
        public byte? PackageCategoryId { get; set; }
        public string ImageName { get; set; }
        public string Destination { get; set; }
    }
}
