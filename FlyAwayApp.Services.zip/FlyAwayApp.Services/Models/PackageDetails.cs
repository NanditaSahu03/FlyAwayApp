﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Infosys.TravelAway.Services.Models
{
    public class PackageDetails
    {
        public byte PackageId { get; set; }
        public long SerialPackageDetailsId { get; set; }
        public string PlacesToVisit { get; set; }
        public string PlacesDescription { get; set; }
        public string DaysAndNight { get; set; }
        public long Price { get; set; }
        public string Accomodation { get; set; }
    }
}
