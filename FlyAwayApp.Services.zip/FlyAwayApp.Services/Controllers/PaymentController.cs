﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Infosys.TravelAway.DataAccessLayer;
using Infosys.TravelAway.Services.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Infosys.TravelAway.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PaymentController : ControllerBase
    {
        TravelAwayRepository dal = null;
        public PaymentController()
        {
            dal = new TravelAwayRepository();
        }


        [HttpPost]
        public int AddPaymentDetails(Models.Payment payObj)
        {
            int returnval = -1;
            try
            {
                int status = dal.AddPaymentDetails(payObj.BookingId, payObj.EmailId);
                if (status > 0)
                {
                    returnval = 1;
                }
                else
                {
                    returnval = 0;
                }
            }
            catch (Exception)
            {
                returnval = -99;
            }
            return returnval;
        }
      
    }
}

