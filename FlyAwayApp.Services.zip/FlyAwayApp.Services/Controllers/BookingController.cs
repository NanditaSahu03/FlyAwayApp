﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infosys.TravelAway.DataAccessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Testing.DataAccessLayer.Models;

namespace Infosys.TravelAway.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class BookingController : Controller
    {
        TravelAwayRepository dal = null;
        public BookingController()
        {
            dal = new TravelAwayRepository();
        }
        public JsonResult GetBookingDetails(string emailid)
        {
            List<Models.BookingDetails> bookingDetails = new List<Models.BookingDetails>();
            try
            {
                List<BookingDetails> dalBookingDetails = null;
                TravelAwayRepository repository = new TravelAwayRepository();
                dalBookingDetails = repository.GetBookingDetails(emailid);

                foreach (var item in dalBookingDetails)
                {
                    bookingDetails.Add(new Models.BookingDetails() { 
                        BookingId=item.BookingId,
                        EmailId=item.EmailId,
                        SerialPackageDetailsId=item.SerialPackageDetailsId,
                        PhoneNo=item.PhoneNo,
                        UserAddress= item.UserAddress,
                        DateOfTravel=item.DateOfTravel,
                        Adults=item.Adults,
                        Children=item.Children,
                        Price=item.Price,
                        Status=item.Status
                    
                    });
                }
            }
            catch (Exception)
            {

                bookingDetails = null;
            }
            return Json(bookingDetails);
        }
       

        [HttpPost]
        public int AddBookingDetail(Models.BookingDetails bookObj)
        {
            int returnval = -1;
            try
            {
                int status = dal.AddBookPackage(bookObj.SerialPackageDetailsId, bookObj.EmailId, Convert.ToInt64(bookObj.PhoneNo), bookObj.UserAddress,
                    bookObj.DateOfTravel, bookObj.Adults, Convert.ToInt32(bookObj.Children));
                if (status > 0)
                {
                    returnval = status;
                }
                else
                {
                    returnval = 0;
                }
            }
            catch (Exception e)
            {

                returnval = -99;
            }
            return returnval;
        }

        public int GetPriceForBooking(int bookingId)
        {
            int val;
            try
            {
                TravelAwayRepository repository = new TravelAwayRepository();
                val = repository.GetPriceForBooking(bookingId);
            }
            catch (Exception)
            {

                val = -99;
            }
            return val;
        }

    }
}
