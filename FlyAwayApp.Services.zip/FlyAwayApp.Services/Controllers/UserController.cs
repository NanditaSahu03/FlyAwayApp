﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infosys.TravelAway.DataAccessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;


namespace Infosys.TravelAway.Services.Controllers
{
    [Route("api/[controller]/[Action]")]
    [ApiController]
    public class UserController : Controller
    {

       TravelAwayRepository dal = new TravelAwayRepository();

        [HttpGet]
        public int ValidateUserCredentials(string email,string password)
        {
            int userRole;
            try
            {

                int valid = dal.ValidateUserCredentials(email,password);
                if (valid == 1)
                {
                    userRole = 1;
                }
                else if (valid == 2)
                    userRole = 2;
                else
                {
                    userRole = 0;
                }
            }
            catch (Exception)
            {
                userRole = -99;
            }
            return userRole;
        }


        public int AddCustomer(Models.Users userObj)
        {
            //string usermessage;
            int retval;
            int status = 0;
            try
            {

                status = dal.RegisterNewCustomer(userObj.FirstName, userObj.LastName, userObj.UserPassword,
                    userObj.Gender, userObj.EmailId, userObj.DateOfBirth, userObj.UserAddress, Convert.ToInt32(userObj.RoleId), 
                    Convert.ToInt64(userObj.PhoneNo));
                if (status > 0)
                {
                    retval = 1;
                    //usermessage = "Registered User Successfully";
                }
                else
                {
                    retval = 0;
                    //usermessage = "Not Registered Please Check constriants";
                }
            }
            catch (Exception e)
            {
                retval = -99;
                //usermessage = "Not Registered,Exception Please Check once";
                
            }
            return retval;
        }

        public JsonResult GetUserFirstname(string emailId)
        {
            string fname;
            TravelAwayRepository repository = new TravelAwayRepository();
            try
            {
                fname = repository.GetUserFirstname(emailId);
            }
            catch (Exception)
            {

                fname = null;
            }
            return Json(fname);
        }

    }
}
