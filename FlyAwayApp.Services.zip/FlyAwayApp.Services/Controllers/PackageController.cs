﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Infosys.TravelAway.DataAccessLayer;
using Infosys.TravelAway.DataAccessLayer.Models;
using Infosys.TravelAway.Services.Models;

namespace Infosys.TravelAway.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PackageController : Controller
    {
        

        public JsonResult GetAllPackage()
        {
            List<Services.Models.Packages> packages = new List<Services.Models.Packages>();

            try
            {
                List<DataAccessLayer.Models.Packages> dalPackages = null;
                TravelAwayRepository repository = new TravelAwayRepository();

                dalPackages = repository.GetAllPackages();
                foreach (var item in dalPackages)
                {
                    packages.Add(new Services.Models.Packages()
                    {
                        PackageId = item.PackageId,
                        PackageName = item.PackageName,
                        PackageDescription = item.PackageDescription,
                        PackageCategoryId = item.PackageCategoryId,
                        ImageName = item.ImageName,
                        Destination = item.Destination

                    });
                }
            }
            catch (Exception e)
            {
                packages = null;
            }
            return Json(packages);

        }



        public JsonResult GetPackageByCategory(int categoryid)
        {
            List<Services.Models.Packages> packages = new List<Services.Models.Packages>();
            try
            {
                List<DataAccessLayer.Models.Packages> dalPackages = null;
                TravelAwayRepository repository = new TravelAwayRepository();

                dalPackages = repository.GetPackageByCategory(categoryid);

                foreach (var item in dalPackages)
                {
                    packages.Add(new Services.Models.Packages()
                    {
                        PackageId = item.PackageId,
                        PackageName = item.PackageName,
                        PackageDescription = item.PackageDescription,
                        PackageCategoryId = item.PackageCategoryId,
                        ImageName = item.ImageName,
                        Destination = item.Destination

                    });
                }
            }
            catch (Exception)
            {

                packages = null;
            }
            return Json(packages);
        }


        public List<Models.PackageDetails> GetPackageDetails(int packageId)
        {
            List<Models.PackageDetails> packageDetails = new List<Models.PackageDetails>();
            try
            {
                List<DataAccessLayer.Models.PackageDetails> dalPackageDetails = null;
                TravelAwayRepository repository = new TravelAwayRepository();
                dalPackageDetails = repository.GetPackageDetails(packageId);

                foreach (var item in dalPackageDetails)
                {
                    packageDetails.Add(new Models.PackageDetails() { 
                        PackageId=item.PackageId,
                        SerialPackageDetailsId=item.SerialPackageDetailsId,
                        PlacesToVisit=item.PlacesToVisit,
                        PlacesDescription=item.PlacesDescription,
                        DaysAndNight=item.DaysAndNight,
                        Price=item.Price,
                        Accomodation=item.Accomodation
                    });
                }
            }
            catch (Exception)
            {
                packageDetails = null;
                throw;
            }
            return packageDetails;
        }
    }
}
