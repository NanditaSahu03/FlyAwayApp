﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infosys.TravelAway.DataAccessLayer;
using Infosys.TravelAway.DataAccessLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Infosys.TravelAway.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class PackageCategoryController : ControllerBase
    {
        TravelAwayRepository dal = null;
        public PackageCategoryController()
        {
            dal = new TravelAwayRepository();
        }

        public JsonResult GetNumberOfPackageByPackageCategoryId()
        {
            List<Models.PackageCategory> packagelist = new List<Models.PackageCategory>();
            try
            {
                List<PackageCategory> dalpackagelist = dal.GetTotalPackagesByCategoryId();
                foreach (var item in dalpackagelist)
                {
                    packagelist.Add(new Models.PackageCategory()
                    {
                        CategoryName = item.CategoryName,
                        NumberOfPackages = item.NumberOfPackages

                    });
                }
            }
            catch (Exception e)
            {

                packagelist = null;
            }

            return new JsonResult(packagelist);
        }
    }
    
}
