﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infosys.TravelAway.DataAccessLayer;
using Infosys.TravelAway.DataAccessLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Infosys.TravelAway.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class BookingPackageController : ControllerBase
    {

        TravelAwayRepository dal = null;
        public BookingPackageController()
        {
            dal = new TravelAwayRepository();
        }






        public JsonResult GetBookingByPackageName()
        {
            List<Models.BookingPackage> bookinglist = new List<Models.BookingPackage>();
            try
            {
                List<BookingPackage> dalbookinglist = dal.GetTotalBookingsByPackageId();
                foreach (var item in dalbookinglist)
                {
                    bookinglist.Add(new Models.BookingPackage()
                    {
                        PackageName = item.PackageName,
                        NumberOfPackages = item.NumberOfPackages

                    });
                }
            }
            catch (Exception e)
            {

                bookinglist = null;
            }

            return new JsonResult(bookinglist);
        }
    }
    
}
