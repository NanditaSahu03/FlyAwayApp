﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infosys.TravelAway.DataAccessLayer;
using Infosys.TravelAway.DataAccessLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Infosys.TravelAway.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class CategoriesController : Controller
    {
        TravelAwayRepository repository;


        public CategoriesController()
        {
            repository = new TravelAwayRepository();
        }


        public JsonResult GetCategories()
        {
            List<Services.Models.Category> catelist = new List<Services.Models.Category>();
            try
            {
                List<Category> dalcategory = null;
                dalcategory = repository.GetCategoriesUsingLinq();
                foreach (var item in dalcategory)
                {
                    catelist.Add(new Services.Models.Category()
                    {
                        CategoryId = item.CategoryId,
                        CategoryName=item.CategoryName
                    }) ;
                }
            }

            catch (Exception ex)
            {
                catelist = null;
            }
            return Json(catelist);

        }

    }


}
