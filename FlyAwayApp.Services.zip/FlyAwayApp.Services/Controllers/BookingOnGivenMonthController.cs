﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Infosys.TravelAway.DataAccessLayer;
using Infosys.TravelAway.DataAccessLayer.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Infosys.TravelAway.Services.Controllers
{
    [Route("api/[controller]/[action]")]
    [ApiController]
    public class BookingOnGivenMonthController : ControllerBase
    {
        TravelAwayRepository dal = null;
        public BookingOnGivenMonthController()
        {
            dal = new TravelAwayRepository();
        }


        public JsonResult GetBookingOnGivenMonth(int month,int year)
        {
            List<Models.BookingOnMonth> bookinglist = new List<Models.BookingOnMonth>();
            try
            {
                List<BookingOnMonth> dalbookinglist = dal.GetBookingOnGivenMonth(month,year);
                foreach (var item in dalbookinglist)
                {
                    bookinglist.Add(new Models.BookingOnMonth()
                    {
                        SerialPackageDetailsId=item.SerialPackageDetailsId,
                        NumberOfBookings=item.NumberOfBookings

                    });
                }
            }
            catch (Exception e)
            {

                bookinglist = null;
            }

            return new JsonResult(bookinglist);
        }
    }
    
}
