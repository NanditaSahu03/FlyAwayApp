import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IPackageCategory } from '../Interfaces/Report Interfaces/PackageCategory';
import { PackageServiceService } from '../Services/package-service.service';
import { IBookingPackage } from '../Interfaces/Report Interfaces/BookingPackage';
import { IBookingOnMonth } from '../Interfaces/Report Interfaces/BookingOnMonth';

@Component({
  selector: 'app-generate-reports',
  templateUrl: './generate-reports.component.html',
  styleUrls: ['./generate-reports.component.css']
})
export class GenerateReportsComponent implements OnInit {
  condition1: boolean;
  condition2: boolean;
  condition3: boolean;
  condition4: boolean;
  condition5: boolean;


  NumberOfPackageCategory: IPackageCategory[];
  NumberOfBookingUnderAPackage: IBookingPackage[];
  NumberOfBookingOnMonth: IBookingOnMonth[];
  constructor(private router: Router, private service: PackageServiceService) {
    if (sessionStorage.getItem('userRole') == null)
      this.router.navigate(['login']);
  }

  ngOnInit() {
    this.service.getNumberOfPackageByPackageCategoryId().subscribe(
      res => { this.NumberOfPackageCategory = res; },
      err => { console.log(err); },
      () => { console.log("Done");}
    );



    this.service.getBookingByPackageName().subscribe(
      res => { this.NumberOfBookingUnderAPackage = res; },
      err => { console.log(err); },
      () => { console.log("Done");}
    );
  }

  getreport(month:number,year:number) {
    console.log(month + " " + year);
    if (month == 0)
      alert("Please select a Month ")
    else if (year < 1900 || year > 9999)
      alert("Please give a Proper Year")
    else
      this.reportmonth(month,year);
  }
  reportmonth(month: number, year: number) {
    this.condition3 = true;
    this.service.getBookingOnGivenMonth(month, year).subscribe(
      res => {
        this.NumberOfBookingOnMonth = res;
        if (this.NumberOfBookingOnMonth.length > 0) {
          this.condition4 = true;
          this.condition5 = false;
        }
        else {
          this.condition5 = true;
          this.condition4 = false;
        }
      },
      err => { console.log(err); },
      () => { console.log("Done");}
    );
  }

  method(id: number) {
    if (id == 0) {
      this.condition1 = false;
      this.condition2 = false;
      this.condition3 = false;
      this.condition4 = false;
      this.condition5 = false;
    }
    if (id == 1) {
      this.condition1 = true;
      this.condition2 = false;
      this.condition3 = false
      this.condition4 = false;
      this.condition5 = false;

    }

    if (id == 2) {
      this.condition1 = false;
      this.condition2 = true;
      this.condition3 = false
      this.condition4 = false;
      this.condition5 = false;
    }
    if (id == 3) {
      this.condition1 = false;
      this.condition2 = false;
      this.condition3 = true;
      this.condition4 = false;
      this.condition5 = false;
    }
  }
  logout() {
    sessionStorage.removeItem('userRole');
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('email');
    this.router.navigate(['home'])
  }
}
