import { Component, OnInit } from '@angular/core';
import { IBooking } from '../Interfaces/IBooking';
import { PackageServiceService } from '../Services/package-service.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.css']
})
export class BookingComponent implements OnInit {
  serialPackageDetailsId: number;
  emailid: string;
  payments: boolean;
  bookingID: number;
  finalprice: number;
  constructor(private _service:PackageServiceService,private route:ActivatedRoute,private router:Router) { }
  ngOnInit() {
    this.emailid = String(sessionStorage.getItem('email'));
    this.serialPackageDetailsId = Number(this.route.snapshot.params['serialPackageDetailsId']);
  }
  bookingdetail(contactnumber: number, address: string, datetravel: Date, adults: number, children: number) {
    let child: number
    if (new Date() > new Date(datetravel)) {
      alert("Please give a future date.")
      return;
    }
    if (adults < 1) {
      alert("Number of adults should be greater than 1.")
      return;
    }
    if (children == null)
      child = 0;
    else
      child=children
    console.log(children);
    let bookinguser: IBooking = {
      bookingId: 0, emailId: this.emailid, serialPackageDetailsId: this.serialPackageDetailsId, phoneNo:Number( contactnumber), userAddress: address, dateOfTravel: new Date(datetravel),
      adults: Number(adults), children: Number(children), price: 100, status: 'Booked'
    }
    console.log(bookinguser);
    this._service.addBookingDetails(bookinguser).subscribe(
      bookingsuccess => {
        if (bookingsuccess >= 1) {
          this.bookingID = bookingsuccess;
          this.payments = true;
        }
        else {
          alert("something is wrong");
          this.payments = false;
        }
      },
      bookingerr => { console.log(bookingerr); },
      () => { console.log("Done"); }
    )
  }

  pay() {
    this._service.getPriceForBooking(this.bookingID).subscribe(
      res => {
        this.finalprice = res;
        sessionStorage.setItem('bookingId', String(this.bookingID));
        sessionStorage.setItem('price', String(this.finalprice));
        this.router.navigate(['payment']);
      }
    );
  }

}
