import { Injectable } from '@angular/core';
import { HttpClient,HttpErrorResponse } from '@angular/common/http';
import { Observable,throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { IviewAllPackages } from '../Interfaces/IViewAllPackages';
import { ICategory } from '../Interfaces/ICategory';
import { IUser } from '../Interfaces/IUser';
import { IviewPackageDetails } from '../Interfaces/IpackageDetails';
import { IBooking } from '../Interfaces/IBooking';
import { IPackageCategory } from '../Interfaces/Report Interfaces/PackageCategory';
import { IBookingPackage } from '../Interfaces/Report Interfaces/BookingPackage';
import { IBookingOnMonth } from '../Interfaces/Report Interfaces/BookingOnMonth';
import { Ipayment } from '../Interfaces/Payment';


@Injectable({
  providedIn: 'root'
})
export class PackageServiceService {

  constructor(private http: HttpClient) { }

  getAllPackages(): Observable<IviewAllPackages[]> {
    let temp = this.http.get<IviewAllPackages[]>("https://localhost:44362/api/package/GetAllPackage");
    return temp;
  }


  getAllCategories(): Observable<ICategory[]> {
    let temp = this.http.get<ICategory[]>("https://localhost:44362/api/categories/GetCategories").pipe(catchError(this.errorHandler));
    return temp;
  }

  getPackageByCategory(catid: number):Observable<IviewAllPackages[]> {
    let temp = this.http.get<IviewAllPackages[]>("https://localhost:44362/api/package/GetPackageByCategory?categoryid=" + catid).pipe(catchError(this.errorHandler));
    return temp;
  }

  checkLogin(email: string, password: string):Observable<number> {
    let temp = this.http.get<number>("https://localhost:44362/api/user/ValidateUserCredentials?email=" + email + "&password=" + password).pipe(catchError(this.errorHandler));
    //sessionStorage.setItem('userRole', 'admin');
    return temp;
  }

  registerr(Usr:IUser): Observable<number> {
   
    let temp = this.http.post<number>("https://localhost:44362/api/user/AddCustomer", Usr).pipe(catchError(this.errorHandler));
    return temp;
  }

  getPackageDetails(packageid:number):Observable<IviewPackageDetails[]> {
    let temp = this.http.get<IviewPackageDetails[]>("https://localhost:44362/api/package/GetPackageDetails?packageid=" + packageid).pipe(catchError(this.errorHandler));
    return temp;
  }

  getUserName(emailid: string):Observable<string> {
    let temp = this.http.get<string>("https://localhost:44362/api/user/GetUserFirstname?emailid=" + emailid).pipe(catchError(this.errorHandler));
    return temp;
  }

  addBookingDetails(bookinguser: IBooking): Observable<number> {
    let temp = this.http.post<number>('https://localhost:44362/api/booking/AddBookingDetail', bookinguser).pipe(catchError(this.errorHandler));
    return temp;
  }

  getBookingDetails(emailid: string): Observable<IBooking[]> {
    let temp = this.http.get<IBooking[]>("https://localhost:44362/api/booking/GetBookingDetails?emailid=" + emailid);
    return temp;
  }

  getNumberOfPackageByPackageCategoryId(): Observable<IPackageCategory[]> {
    let temp = this.http.get<IPackageCategory[]>("https://localhost:44362/api/PackageCategory/GetNumberOfPackageByPackageCategoryId");
    return temp;
  }

  getBookingByPackageName(): Observable<IBookingPackage[]> {
    let temp = this.http.get<IBookingPackage[]>("https://localhost:44362/api/bookingpackage/getBookingByPackageName");
    return temp;
  }

  getBookingOnGivenMonth(month: number, year: number): Observable<IBookingOnMonth[]> {
    let temp = this.http.get<IBookingOnMonth[]>("https://localhost:44362/api/BookingOnGivenMonth/GetBookingOnGivenMonth?month=" + month + "&year=" + year);
    return temp;
  }

  addPaymentDetails(paymentuser: Ipayment): Observable<number> {
    let temp = this.http.post<number>('https://localhost:44362/api/Payment/AddPaymentDetails', paymentuser).pipe(catchError(this.errorHandler));
    return temp;
  }

  getPriceForBooking(bookingId: number): Observable<number> {
    return this.http.get<number>("https://localhost:44362/api/booking/GetPriceForBooking?bookingid=" + bookingId);
  }

  errorHandler(error: HttpErrorResponse) {
    console.error(error);
    return throwError(error.message || "Server Error"); 
  } 

}
