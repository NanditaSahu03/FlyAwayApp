import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { ViewAllPackagesComponent } from './view-all-packages/view-all-packages.component';
import { HttpClientModule } from '@angular/common/http'
import { routing } from './app.routing';

import {FormsModule} from '@angular/forms';
import { LoginComponent } from './login/login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component'
import { AuthGuard } from './auth.guard';
import { ViewPackageDetailsComponent } from './view-package-details/view-package-details.component';
import { BookingComponent } from './booking/booking.component';
import { ViewBookingsComponent } from './view-bookings/view-bookings.component';
import { GenerateReportsComponent } from './generate-reports/generate-reports.component';
import { PaymentComponent } from './payment/payment.component';

@NgModule({
  declarations: [
    AppComponent,
    ViewAllPackagesComponent,
    LoginComponent,
    AdminHomeComponent,
    CustomerHomeComponent,
    RegisterComponent,
    HomeComponent,
    ViewPackageDetailsComponent,
    BookingComponent,
    ViewBookingsComponent,
    GenerateReportsComponent,
    PaymentComponent
  ],
  imports: [
    BrowserModule,routing,HttpClientModule,FormsModule
  ],
  providers: [AuthGuard],
  bootstrap: [AppComponent]
})
export class AppModule { }
