import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { PackageServiceService } from '../Services/package-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  UserName: string;
  constructor(private service:PackageServiceService,private router:Router) { }
  loginStatus: number=-1;
  ngOnInit() {
  }

  checklogin(email: string, password: string) {


    this.service.checkLogin(email, password).subscribe(
      res => {
        this.loginStatus = res;
        console.log(this.loginStatus);
        if (this.loginStatus == 1 || this.loginStatus == 2) {
          sessionStorage.setItem('email', email);
          this.service.getUserName(email).subscribe(
            res => { sessionStorage.setItem("userName", res) }
          );
        }
        if (this.loginStatus == 1) {
          sessionStorage.setItem('userRole', 'admin');
          this.router.navigate(['admin']);
        }
        else if (this.loginStatus == 2) {
          sessionStorage.setItem('userRole', 'customer');
          this.router.navigate(['customer']);
        }
        else
          alert("Invalid Credentials")
      },
      err => { console.log(err); },
      () => { console.log("Done");}
    );
    
  }
}
