export interface Ipayment {
  bookingId: number,
  emailId:string
}
