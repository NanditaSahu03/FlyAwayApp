export interface IUser {

  firstName: string,
  lastName: string,
  userpassword: string,
  gender: string,
  emailid: string,
  dateOfBirth: Date,
  
  userAddress: string
  roleId: number,
  phoneNo: number,
  
  



}
