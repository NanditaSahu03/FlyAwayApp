export interface IPackageCategory {
  categoryName: string,
  numberOfPackages:number
}
