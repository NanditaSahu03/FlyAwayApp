export interface IBookingPackage {
  packageName: string,
  numberOfPackages:number
}
