export interface IBookingOnMonth {
  serialPackageDetailsId: number,
  numberOfBookings:number
}
