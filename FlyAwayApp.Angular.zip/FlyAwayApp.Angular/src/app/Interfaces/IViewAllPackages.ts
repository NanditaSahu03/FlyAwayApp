export interface IviewAllPackages {
  packageId: number,
  packageName: string,
  packageDescription: string,
  PackageCategoryId: number,
  imageName: string,
  destination:string
}
