export interface IviewPackageDetails {
  packageId: number,
  serialPackageDetailsId: number,
  placesToVisit: string,
  placesDescription: string,
  daysAndNight: string,
  price: number,
  accomodation:string
}
