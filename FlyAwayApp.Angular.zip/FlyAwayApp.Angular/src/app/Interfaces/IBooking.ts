export interface IBooking {
  bookingId: number,
  emailId: string,
  serialPackageDetailsId: number;
  phoneNo: number,
  userAddress: string,
  dateOfTravel: Date,
  adults: number,
  children: number,
  price: number,
  status: string
}
