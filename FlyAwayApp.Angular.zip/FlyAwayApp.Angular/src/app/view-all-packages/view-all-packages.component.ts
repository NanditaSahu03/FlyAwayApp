import { Component, OnInit } from '@angular/core';
import { PackageServiceService } from '../Services/package-service.service';
import { IviewAllPackages } from '../Interfaces/IViewAllPackages';
import { ICategory } from '../Interfaces/ICategory';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-all-packages',
  templateUrl: './view-all-packages.component.html',
  styleUrls: ['./view-all-packages.component.css']
})
export class ViewAllPackagesComponent implements OnInit {

  constructor(private service: PackageServiceService,private router:Router) {
    if (sessionStorage.getItem('userRole') == null)
      this.router.navigate(['login']);
  
  }

  AllPackages: IviewAllPackages[];
  filteredPackages: IviewAllPackages[];
  Categories: ICategory[];
  categoryname: string;
  noPackage: boolean=false;
  cat: string = null;

  ngOnInit() {

    this.service.getAllCategories().subscribe(
      res => {
        this.Categories = res;
      },
      err => {
        console.log(err);
      },
      () => {
        console.log("Done");
      }
    );




    this.service.getAllPackages().subscribe(
      res => {
        this.AllPackages = res;
        this.filteredPackages = res;
        if (this.AllPackages.length == 0)
          this.noPackage = true;
      },
      err => {
        console.log(err);
      },
      () => {
        console.log("Done");
      }

    );

   
  }

  method(val: number) {
    console.log(val);
   
    //if (temp == 0)
    //  this.filteredPackages = this.AllPackages;
    //else
    //  this.filteredPackages = this.AllPackages.filter(res => Number(res.PackageCategoryId) == Number(val));


    if (val == 0)
      this.filteredPackages = this.AllPackages;
    else {
      this.service.getPackageByCategory(val).subscribe(
        res => {
          this.filteredPackages = res;
          if (this.filteredPackages.length == 0)
            this.noPackage = true;
        },
        err => {
          console.log(err);
        },
        () => {
          console.log("Done");
        }

      );
    }

  }

  logout() {
    sessionStorage.removeItem('userRole');
    sessionStorage.removeItem('email');
    sessionStorage.removeItem('userName');
    this.router.navigate(['home'])
  }


  navigate(packageid:number,packageName:string) {
    this.router.navigate(['details', Number(packageid), String(packageName)])
  }

}
