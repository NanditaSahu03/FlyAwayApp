import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-admin-home',
  templateUrl: './admin-home.component.html',
  styleUrls: ['./admin-home.component.css']
})
export class AdminHomeComponent implements OnInit {
  userName: string;
  constructor(private router: Router) {
    this.userName = sessionStorage.getItem('userName');
    if (sessionStorage.getItem('userRole') == null)
      this.router.navigate(['login']);
  }

  ngOnInit() {
  }
  logout() {
    sessionStorage.removeItem('userRole');
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('email');
    this.router.navigate(['home'])
  }
}
