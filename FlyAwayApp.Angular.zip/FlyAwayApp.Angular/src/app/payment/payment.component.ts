import { Component, OnInit } from '@angular/core';
import { PackageServiceService } from '../Services/package-service.service';
import { Ipayment } from '../Interfaces/Payment';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  bookingId: number
  amount: number
  confirm: boolean
  emailId: string
  constructor(private _service: PackageServiceService, private route: ActivatedRoute) {
 
  }

  ngOnInit() {
    this.emailId = String(sessionStorage.getItem('email'));
    this.bookingId = Number(sessionStorage.getItem("bookingId"));
    this.amount = Number(sessionStorage.getItem("price"));
    console.log(this.amount);
  }
  paymentdetail() {

    let paymentuser: Ipayment = {
      bookingId: this.bookingId, emailId: this.emailId
    };

    console.log(paymentuser);


    this._service.addPaymentDetails(paymentuser).subscribe(
      paymentsuccess => {
        if (paymentsuccess == 1) {
          this.confirm = true;
          sessionStorage.removeItem("bookingId");
          sessionStorage.removeItem("price");

        }
        else {
          alert("something is wrong");
          this.confirm = false;
        }
      },
      paymenterr => { console.log(paymenterr); },
      () => { console.log("Done"); }
    )
  }

}
