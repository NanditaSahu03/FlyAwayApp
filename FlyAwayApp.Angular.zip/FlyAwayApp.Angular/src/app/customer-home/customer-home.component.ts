import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-customer-home',
  templateUrl: './customer-home.component.html',
  styleUrls: ['./customer-home.component.css']
})
export class CustomerHomeComponent implements OnInit {
  userName: string;
  constructor(private router: Router, private route: ActivatedRoute) {
    this.userName = sessionStorage.getItem('userName');
    if (sessionStorage.getItem('userRole') == null)
      this.router.navigate(['login']);
    
  }

  ngOnInit() {
    this.userName = sessionStorage.getItem('userName');
  }

  logout() {
    sessionStorage.removeItem('userRole');
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('email');
    this.router.navigate(['home'])
  }
}
