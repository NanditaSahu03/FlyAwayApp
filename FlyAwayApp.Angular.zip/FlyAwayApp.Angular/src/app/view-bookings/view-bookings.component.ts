import { Component, OnInit } from '@angular/core';
import { IBooking } from '../Interfaces/IBooking';
import { PackageServiceService } from '../Services/package-service.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-bookings',
  templateUrl: './view-bookings.component.html',
  styleUrls: ['./view-bookings.component.css']
})
export class ViewBookingsComponent implements OnInit {
  emailId: string;
  bookings: IBooking[];
  constructor(private service:PackageServiceService,private router:Router) { }

  ngOnInit() {
    this.emailId = sessionStorage.getItem('email');
    this.service.getBookingDetails(this.emailId).subscribe(
      res => { this.bookings = res; },
      err => { console.log(err); },
      () => { console.log("Done");}
    );
   
  }

  logout() {
    sessionStorage.removeItem('userRole');
    sessionStorage.removeItem('email');
    sessionStorage.removeItem('userName');
    this.router.navigate(['home'])
  }
  pay(bookingid: number, price: number) {
    sessionStorage.setItem('bookingId', String(bookingid));
    sessionStorage.setItem('price', String(price));
    this.router.navigate(['payment']);
  
  }

}
