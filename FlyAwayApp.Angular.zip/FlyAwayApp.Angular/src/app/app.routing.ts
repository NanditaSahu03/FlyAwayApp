import { RouterModule, Routes } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { ViewAllPackagesComponent } from './view-all-packages/view-all-packages.component';
import { LoginComponent } from './login/login.component';
import { AdminHomeComponent } from './admin-home/admin-home.component';
import { CustomerHomeComponent } from './customer-home/customer-home.component';
import { RegisterComponent } from './register/register.component';
import { HomeComponent } from './home/home.component';
import { AuthGuard } from './auth.guard';
import { ViewPackageDetailsComponent } from './view-package-details/view-package-details.component';
import { BookingComponent } from './booking/booking.component';
import { ViewBookingsComponent } from './view-bookings/view-bookings.component';
import { GenerateReportsComponent } from './generate-reports/generate-reports.component';
import { PaymentComponent } from './payment/payment.component';

const routes: Routes = [
  { path: '', component: HomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'view', component: ViewAllPackagesComponent },
  { path: 'login', component: LoginComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'admin', component: AdminHomeComponent },
  { path: 'report', component: GenerateReportsComponent },
  { path: 'viewbooking', component: ViewBookingsComponent },
  { path: 'payment', component: PaymentComponent },
  { path: 'booking/:serialPackageDetailsId', component: BookingComponent },
  { path: 'details/:packageid/:packageName', component: ViewPackageDetailsComponent },
  { path: 'customer' ,component: CustomerHomeComponent }
];
export const routing: ModuleWithProviders = RouterModule.forRoot(routes);
