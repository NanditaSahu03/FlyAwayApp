import { Component, OnInit } from '@angular/core';
import { PackageServiceService } from '../Services/package-service.service';

import { Observable, throwError } from 'rxjs';
import { IUser } from '../Interfaces/IUser';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  condition: boolean;
  constructor(private service:PackageServiceService,private router:Router) { }

  ngOnInit() {
  }

  register(email: string, fname: string, lname: string, password: string, cpassword: string, gender: string, phone: number, birth: Date, address: string) {
    if (fname.indexOf(' ') >= 0)
      alert("First name has space")

    else if (lname.indexOf(' ') >= 0)
      alert("Last name has space")

    else if (password.length < 8 || password.length > 16)
      alert("Password Length must be of size 8");

    else if (password != cpassword)
      alert("Password and Confirmed Password did't match!!")

    else if (gender == "0")
      alert("Select the Gender")

    else if (new Date(birth) >= new Date())
      alert("Birth date must be Historic")



    else
      this.finalRegister(email,fname,lname,password,gender,phone,birth,address)
  }

  finalRegister(email: string, fname: string, lname: string, password: string, gender: string, phone: number, birth: Date, address: string) {
    let role: number = 2;
    let Usr: IUser = { firstName: fname, lastName: lname, userpassword: password, gender: gender, emailid: email, dateOfBirth: new Date(birth),userAddress:address,roleId:2,phoneNo:phone}
    this.service.registerr(Usr).subscribe(
      res => {
        if (res == 1) {
          this.condition = true;
          this.ngOnInit();
        }
        else
          alert("something is wrong");
      },
      err => { console.log(err); },
      () => { console.log("Done");}
    );
  }
}
