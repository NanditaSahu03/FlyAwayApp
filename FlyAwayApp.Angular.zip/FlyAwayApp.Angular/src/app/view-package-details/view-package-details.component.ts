import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { IviewPackageDetails } from '../Interfaces/IpackageDetails';
import { PackageServiceService } from '../Services/package-service.service';

@Component({
  selector: 'app-view-package-details',
  templateUrl: './view-package-details.component.html',
  styleUrls: ['./view-package-details.component.css']
})
export class ViewPackageDetailsComponent implements OnInit {
  packageId: number;
  packageName: string;
  packageDetails: IviewPackageDetails[];
  constructor(private route: ActivatedRoute, private service: PackageServiceService, private router: Router) {
    if (sessionStorage.getItem('userRole') == null)
      this.router.navigate(['login']);
  }

  ngOnInit() {
    this.packageId = Number(this.route.snapshot.params['packageid']);
    this.packageName = String(this.route.snapshot.params['packageName']);
    this.service.getPackageDetails(this.packageId).subscribe(
      res => {
        this.packageDetails = res;
        console.log(this.packageDetails);
      },
      err => { console.log(err); },
      () => { console.log("Done");}

    );
    console.log(this.packageDetails);
  }
  logout() {
    sessionStorage.removeItem('userRole');
    sessionStorage.removeItem('userName');
    sessionStorage.removeItem('email');
    this.router.navigate(['home'])
  }
  book(serialPackageDetailsId: number) {
    this.router.navigate(['booking', serialPackageDetailsId])
  }


}
