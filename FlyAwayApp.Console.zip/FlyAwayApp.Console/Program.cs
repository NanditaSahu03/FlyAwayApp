﻿
using System;
using System.Collections.Generic;
using System.Linq;
using Infosys.TravelAway.DataAccessLayer;
using Infosys.TravelAway.DataAccessLayer.Models;

namespace Infosys.TravelAway.Console
{
    class Program
    {
        static void Main(string[] args)
        {
            TravelAwayRepository repository = new TravelAwayRepository();
            //var packages = repository.GetAllPackages();
            //foreach (var item in packages)
            //{
            //    System.Console.WriteLine(item.PackageName);
            //}


            //var packages = repository.GetPackageByCategory(5);
            //foreach (var item in packages)
            //{
            //    System.Console.WriteLine(item.PackageName + " " + item.ImageName);
            //}
            //System.Console.WriteLine("hello world!");



            //var packgelist = repository.GetTotalPackagesByCategoryId();
            //try
            //{
            //    foreach (var item in packgelist)
            //    {
            //        System.Console.WriteLine(item.CategoryName + " " + item.NumberOfPackages);
            //    }
            //}
            //catch (Exception e)
            //{

            //    System.Console.WriteLine(e.Message);
            //}



            //var categories = repository.GetCategoriesUsingLinq();
            //if (categories != null)
            //{
            //    foreach (var item in categories)
            //    {
            //        System.Console.WriteLine(item.CategoryId + " " + item.CategoryName);
            //    }

            //}
            //else
            //{
            //    System.Console.WriteLine("Error in  categories");

            //}

            //string emailid = "Nanditasahu@gmail.com";
            //string userpassword = "Nandita@123";
            //int status = repository.ValidateUserCredentials(emailid, userpassword);
            ////System.Console.WriteLine(status);
            //if (status == 1 || status == 2)
            //{
            //    System.Console.WriteLine(status);
            //}
            //else
            //{
            //    System.Console.WriteLine("Not valid");
            //}



            //string firstName = "Abhi";
            //string lastName = "saha";
            //string emailid = "abhisahu@gmail.com";
            //string gender = "M";
            //int roleid = 1;
            //string address = "kolkata";
            //string userpassword = "88888887";
            //long phoneno = 8965142568;
            //DateTime userdate = new DateTime(year: 2019, month: 05, day: 18);
            //int status = repository.RegisterNewCustomer(firstName, lastName, userpassword, gender, emailid, userdate, address, roleid, phoneno);
            //System.Console.WriteLine(status);
            //System.Console.WriteLine(status);
            //if (status > 0)
            //{
            //    System.Console.WriteLine("Success in registeration");
            //}
            //else
            //{
            //    System.Console.WriteLine("PLEASE added correct details in registeration form");
            //}

            //var temp = repository.GetPackageDetails(8);
            //foreach (var item in temp)
            //{
            //    System.Console.WriteLine(item.PlacesToVisit + " " + item.PlacesDescription);
            //}


            //int status = repository.AddBookPackage(6, "boombasaha@gmail.com", 9085474800, "Hauptstr. 29", new DateTime(2021, 11, 10), 1, 2);
            //System.Console.WriteLine(status);
            //try
            //{
            //    if (status > 0)
            //    {
            //        System.Console.WriteLine("Added booking details successfully");
            //    }
            //    else
            //    {
            //        System.Console.WriteLine("There is some problem in your input..check booking details");
            //    }

            //}
            //catch (Exception e)
            //{

            //    System.Console.WriteLine("Exception error in booking details: " + e.Message);
            //}


            // System.Console.WriteLine(repository.GetPriceForBooking(39));








            //var bookinglist = repository.GetTotalBookingsByPackageId();
            //foreach (var item in bookinglist)
            //{
            //    System.Console.WriteLine(item.PackageName + " " + item.NumberOfPackages);
            //}






            //int status = repository.AddPaymentDetails(11,"Nanditasahu@gmail.com");
            //System.Console.WriteLine(status);
            //try
            //{
            //    if (status > 0)
            //    {
            //        System.Console.WriteLine("Added payment details successfully");
            //    }
            //    else
            //    {
            //        System.Console.WriteLine("There is some problem in your input..check payment details");
            //    }

            //}
            //catch (Exception e)
            //{

            //    System.Console.WriteLine("Exception error in payment details: " + e.Message);
            //}



            //System.Console.WriteLine(repository.AddBookPackage(2,"silajitsaha@gmail.com",8617283014,"Sodeput",new DateTime(year:2020,month:12,day:25),4,2));
            //System.Console.WriteLine(repository.AddPaymentDetails(12,"silajitsaha@gmail.com"));

            //System.Console.WriteLine(repository.GetUserFirstname("Boombasaha@gmail.com"));

            //var temp = repository.GetBookingOnGivenMonth(11, 2020);
            //foreach (var item in temp)
            //{
            //    System.Console.WriteLine(item.NumberOfBookings+" "+item.SerialPackageDetailsId);
            //}
        }
    }
}

