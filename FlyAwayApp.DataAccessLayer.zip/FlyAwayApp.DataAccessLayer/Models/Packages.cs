﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class Packages
    {
        public Packages()
        {
            PackageDetails = new HashSet<PackageDetails>();
        }

        public byte PackageId { get; set; }
        public string PackageName { get; set; }
        public string PackageDescription { get; set; }
        public byte? PackageCategoryId { get; set; }
        public string ImageName { get; set; }
        public string Destination { get; set; }

        public virtual Category PackageCategory { get; set; }
        public virtual ICollection<PackageDetails> PackageDetails { get; set; }
    }
}
