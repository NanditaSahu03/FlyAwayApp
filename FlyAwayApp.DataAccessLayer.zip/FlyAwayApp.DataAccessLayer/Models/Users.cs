﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using Testing.DataAccessLayer.Models;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class Users
    {
        public Users()
        {
            BookingDetails = new HashSet<BookingDetails>();
            PaymentDetails = new HashSet<PaymentDetails>();
        }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        [Key]
        public string EmailId { get; set; }
        public string UserPassword { get; set; }
        public string Gender { get; set; }
        public decimal PhoneNo { get; set; }
        public DateTime DateOfBirth { get; set; }
        public string UserAddress { get; set; }
        public byte? RoleId { get; set; }

        public virtual Roles Role { get; set; }
        public virtual ICollection<BookingDetails> BookingDetails { get; set; }
        public virtual ICollection<PaymentDetails> PaymentDetails { get; set; }
    }
}
