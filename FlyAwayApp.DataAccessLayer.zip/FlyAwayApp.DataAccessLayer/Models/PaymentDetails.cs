﻿using Infosys.TravelAway.DataAccessLayer.Models;
using System;
using System.Collections.Generic;

namespace Testing.DataAccessLayer.Models
{
    public partial class PaymentDetails
    {
        public int PaymentId { get; set; }
        public int? BookingId { get; set; }
        public string EmailId { get; set; }
        public decimal Amount { get; set; }

        public virtual BookingDetails Booking { get; set; }
        public virtual Users Email { get; set; }
    }
}
