﻿using Infosys.TravelAway.DataAccessLayer.Models;
using System;
using System.Collections.Generic;

namespace Testing.DataAccessLayer.Models
{
    public partial class BookingDetails
    {
        public BookingDetails()
        {
            PaymentDetails = new HashSet<PaymentDetails>();
        }

        public int BookingId { get; set; }
        public string EmailId { get; set; }
        public long SerialPackageDetailsId { get; set; }
        public decimal PhoneNo { get; set; }
        public string UserAddress { get; set; }
        public DateTime DateOfTravel { get; set; }
        public int Adults { get; set; }
        public int? Children { get; set; }
        public decimal Price { get; set; }
        public string Status { get; set; }

        public virtual Users Email { get; set; }
        public virtual ICollection<PaymentDetails> PaymentDetails { get; set; }
    }
}
