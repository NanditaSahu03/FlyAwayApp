﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public class BookingPackage
    {
        [Key]
        public string PackageName { get; set; }
        public int NumberOfPackages { get; set; }
    }
}
