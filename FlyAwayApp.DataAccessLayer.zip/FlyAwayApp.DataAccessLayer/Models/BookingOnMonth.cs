﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public class BookingOnMonth
    {
        [Key]
        public long SerialPackageDetailsId { get; set; }
        public int NumberOfBookings { get; set; }
    }
}
