﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class Category
    {
        public Category()
        {
            Packages = new HashSet<Packages>();
        }

        public byte CategoryId { get; set; }
        public string CategoryName { get; set; }

        public virtual ICollection<Packages> Packages { get; set; }
    }
}
