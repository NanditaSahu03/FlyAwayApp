﻿using System;
using System.Collections.Generic;

namespace Infosys.TravelAway.DataAccessLayer.Models
{
    public partial class PackageDetails
    {
        public byte PackageId { get; set; }
        public long SerialPackageDetailsId { get; set; }
        public string PlacesToVisit { get; set; }
        public string PlacesDescription { get; set; }
        public string DaysAndNight { get; set; }
        public long Price { get; set; }
        public string Accomodation { get; set; }

        public virtual Packages Package { get; set; }
    }
}
