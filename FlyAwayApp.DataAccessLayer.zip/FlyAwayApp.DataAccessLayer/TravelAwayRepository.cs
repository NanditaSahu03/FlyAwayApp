﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Infosys.TravelAway.DataAccessLayer.Models;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Testing.DataAccessLayer.Models;

namespace Infosys.TravelAway.DataAccessLayer
{
    public class TravelAwayRepository
    {
        TravelAwayContext context;

        public TravelAwayRepository()
        {
            context = new TravelAwayContext();
        }

        public List<Packages> GetAllPackages()
        {
            List<Packages> packages = new List<Packages>();
            try
            {
                packages = context.Packages.FromSqlRaw("select * from dbo.ufn_ViewAllPackages()").ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine("Error Occures pls check" + e.Message);
                packages = null;
            }
            return packages;
        }


        public List<Packages> GetPackageByCategory(int categoryId)
        {
            List<Packages> packages = null;
            try
            {
                SqlParameter prmCategoryId = new SqlParameter("@CategoryId", categoryId);
                packages = context.Packages.FromSqlRaw("select * from dbo.ufn_ViewPackageByCAtegory(@CategoryId)", prmCategoryId).ToList();
            }
            catch (Exception)
            {

                packages = null;
            }
            return packages;
        }


        public List<PackageCategory> GetTotalPackagesByCategoryId()
        {
            List<PackageCategory> countpackages = null;
            try
            {

                countpackages = context.PackageCategory.FromSqlRaw("select * from dbo.ufn_PackageByPackageCategoryId()").ToList();
            }
            catch (Exception)
            {

                countpackages = null;
            }
            return countpackages;
        }



        public List<Category> GetCategoriesUsingLinq()
        {
            List<Category> lstCategories = null;
            try
            {
                lstCategories = (from c in context.Category
                                 orderby c.CategoryId
                                     ascending
                                 select c).ToList<Category>();
            }
            catch (Exception)
            {
                lstCategories = null;
            }
            return lstCategories;
        }


        public int ValidateUserCredentials(string emailId, string userPassword)
        {
            int returnvalue = 0;
            try
            {
                returnvalue = (from s in context.Users
                               select TravelAwayContext.ufn_ValidateUserCredentials(emailId, userPassword))
                             .FirstOrDefault();
            }
            catch (Exception ex)
            {
                returnvalue = -99;
            }
            return returnvalue;
        }







        public int RegisterNewCustomer(string firstName, string lastName, string userPassword, string gender, string emailId, DateTime dateOfBirth, string address, int roleId, long phoneno)
        {
            int result = -1, returnresult = 0;

            try
            {
                SqlParameter prmfirstName = new SqlParameter("@FirstName", firstName);
                SqlParameter prmlastName = new SqlParameter("@LastName", lastName);
                SqlParameter prmphoneno = new SqlParameter("@PhoneNo", phoneno);
                SqlParameter prmuserPassword = new SqlParameter("@UserPassword", userPassword);
                SqlParameter prmgender = new SqlParameter("@Gender", gender);
                SqlParameter prmemailId = new SqlParameter("@EmailId", emailId);
                SqlParameter prmdateofBirth = new SqlParameter("@DateOfBirth", dateOfBirth);
                SqlParameter prmaddress = new SqlParameter("@Address", address);
                SqlParameter prmroleid = new SqlParameter("@RoleId", roleId);


                SqlParameter prmreturnval = new SqlParameter("@retvalue", System.Data.SqlDbType.TinyInt);
                prmreturnval.Direction = System.Data.ParameterDirection.Output;

                result = context.Database.ExecuteSqlRaw("EXEC @retvalue=dbo.usp_AddCustomer @FirstName,@LastName,@EmailId,@UserPassword,@Gender,@PhoneNo,@DateOfBirth,@Address,@RoleId",
                    new[] { prmreturnval, prmfirstName, prmlastName, prmemailId, prmuserPassword, prmgender, prmphoneno, prmdateofBirth, prmaddress, prmroleid });

                returnresult = Convert.ToInt32(prmreturnval.Value);
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                returnresult = -99;
            }
            return returnresult;
        }



        public List<PackageDetails> GetPackageDetails(int packageId)
        {
            List<PackageDetails> packageDetails = null;
            try
            {
                packageDetails = (from p in context.PackageDetails where p.PackageId == packageId select p).ToList();

            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                packageDetails = null;
            }
            return packageDetails;
        }


        public int AddBookPackage(long SerialPackageDetailsid, string emailId, long phoneno, string address, DateTime dateOfTravel, int adults
            , int children)
        {
            int result = -1, returnresult = 0;

            try
            {
                SqlParameter prmserialpackagedetailsid = new SqlParameter("@SerialPackageDetailsId", SerialPackageDetailsid);
                SqlParameter prmemailId = new SqlParameter("@EmailId", emailId);
                SqlParameter prmphoneno = new SqlParameter("@PhoneNo", phoneno);
                SqlParameter prmuseraddress = new SqlParameter("@UserAddress", address);
                SqlParameter prmdateoftravel = new SqlParameter("@DateOfTravel", dateOfTravel);
                SqlParameter prmadults = new SqlParameter("@Adults", adults);
                SqlParameter prmchildren = new SqlParameter("@Children", children);



                SqlParameter prmreturnval = new SqlParameter("@retvalue", System.Data.SqlDbType.TinyInt);
                prmreturnval.Direction = System.Data.ParameterDirection.Output;

                result = context.Database.ExecuteSqlRaw("EXEC @retvalue=dbo.usp_AddBookPackage @SerialPackageDetailsId,@EmailId,@PhoneNo,@UserAddress,@DateOfTravel,@Adults,@Children",
                    new[] { prmreturnval, prmserialpackagedetailsid, prmemailId, prmphoneno, prmuseraddress, prmdateoftravel, prmadults, prmchildren });

                returnresult = Convert.ToInt32(prmreturnval.Value);
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                returnresult = -99;
            }
            return returnresult;
        }


        public int GetPriceForBooking(int bookingId)
        {
            TravelAwayRepository repository1 = new TravelAwayRepository();
            int val;
            try
            {
                val =Convert.ToInt32( (from s in context.BookingDetails where s.BookingId == bookingId select s.Price).FirstOrDefault());
            }
            catch (Exception)
            {

                val = -99;
            }
            return val;
        }


        public List<BookingDetails> GetBookingDetails(string emailid)
        {
            List<BookingDetails> bookingDetails = null;
            try
            {
                bookingDetails = (from bd in context.BookingDetails where bd.EmailId == emailid select bd).ToList();
            }
            catch (Exception)
            {

                bookingDetails = null;
            }
            return bookingDetails;
        }




        public List<BookingPackage> GetTotalBookingsByPackageId()
        {
            List<BookingPackage> countbooking = null;
            try
            {

                countbooking = context.BookingPackage.FromSqlRaw("select * from dbo.ufn_BookingBasedOnPackageName()").ToList();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                countbooking = null;
            }
            return countbooking;
        }



        public List<BookingOnMonth> GetBookingOnGivenMonth(int month,int year)
        {
            List<BookingOnMonth> bookingsongivenmonth = null;
            try
            {
                SqlParameter prmmonth = new SqlParameter("@Month", month);
                SqlParameter prmyear = new SqlParameter("@Year", year);
                bookingsongivenmonth = context.BookingOnMonth.FromSqlRaw("select * from dbo.ufn_GetBookingOnGivenMonth(@Month,@Year)",prmmonth,prmyear).ToList();
            }
            catch (Exception es)
            {
                Console.WriteLine(es.Message);
                bookingsongivenmonth = null;
            }
            return bookingsongivenmonth;
        }




        public int AddPaymentDetails(int bookingId, string emailId)
        {
            int result = -1, returnresult = 0;

            try
            {
                SqlParameter prmbookingId = new SqlParameter("@BookingId", bookingId);
                SqlParameter prmemailId = new SqlParameter("@EmailId", emailId);


                SqlParameter prmreturnval = new SqlParameter("@retvalue", System.Data.SqlDbType.TinyInt);
                prmreturnval.Direction = System.Data.ParameterDirection.Output;

                result = context.Database.ExecuteSqlRaw("EXEC @retvalue=dbo.usp_AddPaymentDetails @BookingId,@EmailId",
                    new[] { prmreturnval, prmbookingId, prmemailId });

                returnresult = Convert.ToInt32(prmreturnval.Value);
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
                returnresult = -99;
            }
            return returnresult;
        }


        public string GetUserFirstname(string emailid)
        {
            string fname, lname;
            try
            {
                fname = (from s in context.Users where s.EmailId == emailid select s.FirstName).FirstOrDefault();
                lname = (from s in context.Users where s.EmailId == emailid select s.LastName).FirstOrDefault();
            }
            catch (Exception)
            {
                lname = null;
                fname = null;
            }
            return (fname + " " + lname);
        }


       

    }
}
